/*
 * Starter code for proxy lab.
 * Feel free to modify this code in whatever way you wish.
 */

/* Some useful includes to help you get started */

#include "cache.h"
#include "csapp.h"
#include "http_parser.h"

#include <assert.h>
#include <ctype.h>
#include <inttypes.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <unistd.h>

#include <errno.h>
#include <netdb.h>
#include <netinet/in.h>
#include <pthread.h>
#include <signal.h>
#include <sys/socket.h>
#include <sys/types.h>

/*
 * Debug macros, which can be enabled by adding -DDEBUG in the Makefile
 * Use these if you find them useful, or delete them if not
 */
#ifdef DEBUG
#define dbg_assert(...) assert(__VA_ARGS__)
#define dbg_printf(...) fprintf(stderr, __VA_ARGS__)
#else
#define dbg_assert(...)
#define dbg_printf(...)
#define MAXLINE 1024
#endif

/*
 * Max cache and object sizes
 * You might want to move these to the file containing your cache implementation
 */
#define MAX_CACHE_SIZE (1024 * 1024)
#define MAX_OBJECT_SIZE (100 * 1024)

/*
 * String to use for the User-Agent header.
 * Don't forget to terminate with \r\n
 */
static const char *header_user_agent = "Mozilla/5.0"
                                       " (X11; Linux x86_64; rv:3.10.0)"
                                       " Gecko/20210731 Firefox/63.0.1";

static const char *terminal_seq = "\r\n";

static pthread_mutex_t cachelock;
static cache_t *cache;

void sigpipe_handler(int sig) {
    // Do nothing on sigpipe
    int olderrno = errno;
    errno = olderrno;
    return;
}

// Parser's current line must be a GET HTTP request
void buffer_forwarded_request(char *request, parser_t *parser) {
    char *rbuf;
    parser_retrieve(parser, METHOD, &rbuf);
    strcpy(request, rbuf);
    strcat(request, " ");

    parser_retrieve(parser, PATH, &rbuf);
    strcat(request, rbuf);

    strcat(request, " HTTP/");

    parser_retrieve(parser, HTTP_VERSION, &rbuf);
    strcat(request, rbuf);

    strcat(request, terminal_seq);
}

void *thread_service_client(void *arg) {
    // Server and client file descriptors
    int cfd;
    int sfd;

    // Parser values
    parser_t *parser;
    parser_state st;
    char *host, *port, *uri;

    // I/O Buffers
    char linebuf[MAXLINE], reqbuf[MAXLINE], respbuf[MAXLINE];
    char cachebuf[MAX_OBJECT_SIZE];
    rio_t rio_client, rio_server;

    // Extract client fd and discard arg holder
    cfd = *((int *)arg);
    pthread_detach(pthread_self());
    free(arg);

    // Set up client I/O read buffer and parser
    rio_readinitb(&rio_client, cfd);
    parser = parser_new();

    // Read and parse the first line, must be a header
    rio_readlineb(&rio_client, linebuf, MAXLINE);
    st = parser_parse_line(parser, linebuf);

    if (st != REQUEST) {
        close(cfd);
        return; // Malformed request, don't serve
    }

    parser_retrieve(parser, URI, &uri);

    // If object is in cache, transmit it
    pthread_mutex_lock(&cachelock);
    ssize_t fetch_size = cache_fetch(cache, uri, cachebuf);
    pthread_mutex_unlock(&cachelock);

    if (fetch_size > -1) {
        rio_writen(cfd, cachebuf, fetch_size);
        close(cfd);
        return;
    }

    // Resolve host and port
    parser_retrieve(parser, HOST, &host);
    parser_retrieve(parser, PORT, &port);
    sfd = open_clientfd(host, port); // Connect to server

    // Couldn't connect to server
    if (sfd < 0) {
        close(cfd);
        return;
    }

    // Forward new request header to server
    buffer_forwarded_request(reqbuf, parser);
    rio_writen(sfd, reqbuf, strlen(reqbuf));

    // Send rest of requests
    while (rio_readlineb(&rio_client, reqbuf, MAXLINE) > 0) {
        rio_writen(sfd, reqbuf, strlen(reqbuf));

        // Prevents hanging after receiving end of message
        if (strcmp(reqbuf, terminal_seq) == 0)
            break;
    }

    // Set up server I/O read buffer
    rio_readinitb(&rio_server, sfd);

    // Buffer server response and send to client
    ssize_t respsize = 0;
    ssize_t obj_size = 0;
    while ((respsize = rio_readnb(&rio_server, respbuf, MAXLINE)) > 0) {
        // Copy read bytes
        if (obj_size + respsize <= MAX_OBJECT_SIZE) {
            memcpy(cachebuf + obj_size, respbuf, respsize);
        }
        rio_writen(cfd, respbuf, respsize);
        obj_size += respsize;
    }

    if (obj_size <= MAX_OBJECT_SIZE) {
        pthread_mutex_lock(&cachelock);
        cache_add(cache, uri, cachebuf, obj_size);
        pthread_mutex_unlock(&cachelock);
    }

    close(cfd);
    return;
}

int main(int argc, char **argv) {
    char *port;
    int listenfd;
    int connfd, *connfdp;
    pthread_t tid;

    socklen_t clientlen;
    struct sockaddr_storage clientaddr;
    char client_hostname[MAXLINE], client_port[MAXLINE];

    Signal(SIGPIPE, sigpipe_handler); // Prevents termination on SIGPIPEs

    // Requires a port to listen for incoming connections
    if (argc != 2) {
        sio_printf("Need to provide a listening port!\n");
        exit(0);
    }

    // Get port and start listening
    port = argv[1];
    listenfd = open_listenfd(port);

    // Initialize mutex lock for cache
    pthread_mutex_init(&cachelock, NULL);
    cache = cache_new(MAX_CACHE_SIZE);

    // Start listening for incoming connections until server is shut down
    while (1) {
        clientlen = sizeof(struct sockaddr_storage);
        connfdp = malloc(sizeof(int));
        connfd = accept(listenfd, &clientaddr, &clientlen);
        *connfdp = connfd;

        pthread_create(&tid, NULL, thread_service_client, connfdp);
    }
    close(listenfd);
}
