#include <stdbool.h> 
#include <stddef.h> 

typedef cache_entry_t {
    char *URI;
    char *data;
    ssize_t datalen;
    int refcount;
} entry_t;

typedef entry_list_t {
    entry_list_t prev;
    entry_list_t next;
    entry_t entry;
} entry_list_t;

typedef cache_t {
    ssize_t size_max;
    ssize_t size_curr;
    entry_list_t *entries;
} cache_t;

cache_t *cache_new(ssize_t size_max) {
    cache_t new = malloc(sizeof(cache_t)); // Add error handling

    new->size_max = size_max;
    new->size_curr = 0;
    new->entries = NULL;

    return new;
}

size_t cache_getsize(cache_t *cache) {
    return cache->size_curr;
}

// Returns -1 if the object doesn't exist in the cache, else it returns the size
// of the object
// If it exists and databuf is non-null, copy data in cache to databuf
int cache_fetch(cache_t *cache, char *URI_request, char *databuf) {

    // Linearly search cache, return size if it exists, -1 else
    for (entry_list_t *node = cache->entries; node != NULL; node = node->next) {

        // ENTRY MUST EXIST IF NODE DOES
        entry_t entry = node->entry;
        char *URI_entry = entry->URI;
        if (strcmp(URI_entry, URI_request)) {
            // Move to front of list
            char *data = new->data;
            ssize_t datalen = new->datalen
            memcpy(databuf, data, datalen);
            return datalen;
        }
    }
    return -1;
}

// Adds the object to the cache
// Object must be smaller than max object size or things can get hectic
// Object should also not be in cache already
void cache_add(cache_t *cache, char *URI, char *databuf, size_t datalen) {
    // Removal routine checks each entry's ref count
}