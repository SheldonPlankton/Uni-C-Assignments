
#include <malloc.h>
#include <stddef.h>
#include <sys/types.h>

typedef struct cache_entry_t {
    char *uri;
    char *data;
    ssize_t datalen;
} entry_t;

typedef struct entry_list_t {
    struct entry_list_t *prev;
    struct entry_list_t *next;
    entry_t *entry;
} entry_list_t;

typedef struct cache_t {
    ssize_t size_max;
    ssize_t size_curr;
    entry_list_t *entries;
    entry_list_t *entries_tail;
} cache_t;

cache_t *cache_new(ssize_t size_max);
size_t cache_getsize(cache_t *cache);
int cache_fetch(cache_t *cache, char *URI_request, char *databuf);
void cache_add(cache_t *cache, char *URI, char *databuf, ssize_t datalen);