
#include "cache.h"
#include <assert.h>
#include <errno.h>
#include <stdbool.h>
#include <stddef.h>
#include <string.h>
#include <sys/types.h>

bool is_cache(cache_t *cache) {

    // NULL cache is not a cache
    if (cache == NULL)
        return false;

    // Max must be non-neg
    if (cache->size_max < 0)
        return false;
    if (cache->size_curr < 0)
        return false;
    if (cache->size_curr > cache->size_max)
        return false;

    // Has entries
    if (cache->entries != NULL) {
        if (cache->entries_tail == NULL)
            return false;
        if (cache->entries_tail->next != NULL)
            return false;

        // Walk cache forward
        ssize_t size_cache_forward = 0;

        // Walk backward through cache
        ssize_t size_cache_backward = 0;

        // Compare size to cache size
    }
    return true;
}

cache_t *cache_new(ssize_t size_max) {
    cache_t *new = malloc(sizeof(cache_t)); // Add error handling

    new->size_max = size_max;
    new->size_curr = 0;
    new->entries = NULL;
    new->entries_tail = NULL;

    return new;
}

// Returns -1 if the object doesn't exist in the cache, else it returns the size
// of the object
// If it exists and databuf is non-null, copy data in cache to databuf
int cache_fetch(cache_t *cache, char *uri_request, char *databuf) {

    // Linearly search cache, return size if it exists, -1 else
    for (entry_list_t *node = cache->entries; node != NULL; node = node->next) {

        // ENTRY MUST EXIST IF NODE DOES
        entry_t *entry = node->entry;
        char *URI_entry = entry->uri;
        if (strcmp(URI_entry, uri_request) == 0) {
            if (databuf == NULL)
                return 0;

            // Put at front of list
            entry_list_t *prev = node->prev;
            entry_list_t *next = node->next;

            if (next != NULL) {
                next->prev = prev;
            }

            if (prev != NULL) {
                prev->next = next;

                // Move to front of list if it isn't last elem
                cache->entries->prev = node;
                node->next = cache->entries;
                cache->entries = node;
            }

            if (node == cache->entries_tail) {
            }

            char *data = entry->data;
            ssize_t datalen = entry->datalen;
            memcpy(databuf, data, datalen);
            return datalen;
        }
    }
    return -1;
}

void cache_evict(cache_t *cache, ssize_t datalen) {
    entry_list_t *node = cache->entries_tail;
    entry_list_t *prev = NULL;
    while (((datalen + cache->size_curr) > cache->size_max) && node != NULL) {
        entry_t *entry = node->entry;
        ssize_t evictedlen = entry->datalen;
        cache->size_curr -= evictedlen;
        prev = node->prev;

        char *uri = entry->uri;
        char *data = entry->data;

        free(uri);
        free(data);
        free(entry);
        free(node);

        if (prev != NULL) {
            prev->next = NULL;
        }
        cache->entries_tail = prev;
        node = prev;
    }
}

// Adds the object to the cache
// Object must be smaller than max object size or things can get hectic
// Object should also not be in cache already
void cache_add(cache_t *cache, char *uri, char *databuf, ssize_t datalen) {
    if (cache_fetch(cache, uri, NULL) > -1)
        return;

    // If cache is too full to add entry, evict!
    if (datalen + cache->size_curr > cache->size_max) {
        // Walk from back of list as this is where LRU entries live
        cache_evict(cache, datalen);
    }

    entry_t *entry_new = malloc(sizeof(entry_t));
    if (entry_new == NULL) {
        // MALLOC ERROR
        sio_printf("%s\n", strerror(errno));
        abort();
    }
    char *data_new = calloc(datalen, sizeof(char));
    if (data_new == NULL) {
        // CALLOC error
        sio_printf("%s\n", strerror(errno));
        abort();
    }

    memcpy(data_new, databuf, datalen);

    char *uri_new = calloc(strlen(uri) + 1, sizeof(char));
    if (uri_new == NULL) {
        // CALLOC ERROR
        sio_printf("%s\n", strerror(errno));
        abort();
    }
    memcpy(uri_new, uri, strlen(uri) + 1);

    entry_new->datalen = datalen;
    entry_new->data = data_new;
    entry_new->uri = uri_new;

    // Make new node
    entry_list_t *node_new = malloc(sizeof(entry_list_t));
    node_new->entry = entry_new;
    node_new->next = cache->entries;
    node_new->prev = NULL;

    if (cache->entries != NULL) {
        cache->entries->prev = node_new;
    }

    if (cache->entries_tail == NULL) {
        cache->entries_tail = node_new;
    }
    cache->entries = node_new;
    cache->size_curr += datalen;
}

void print_node(entry_list_t *node) {

    sio_printf("  -- NODE --\n");
    if (node == NULL) {
        sio_printf("  XXX\n");
        return;
    }

    sio_printf("    ADR: %p\n", node);
    sio_printf("    NXT: %p\n", node->next);
    sio_printf("    PRV: %p\n", node->prev);
    sio_printf("     - - - - - -\n");

    entry_t *entry = node->entry;
    sio_printf("    URI: %s\n", entry->uri);
    sio_printf("    LEN: %d\n", entry->datalen);
    sio_printf("\n");
}

void print_cache(cache_t *cache) {
    sio_printf("PRINTING CACHE...\n");
    sio_printf("CACHE:\n   |C| = %d\nmax|C| = %d\n", cache->size_curr,
               cache->size_max);
    sio_printf("HEAD\n");
    print_node(cache->entries);
    sio_printf("TAIL\n");
    print_node(cache->entries_tail);
    sio_printf("STARTLIST\n");
    for (entry_list_t *node = cache->entries; node != NULL; node = node->next) {
        print_node(node);
    }
}
