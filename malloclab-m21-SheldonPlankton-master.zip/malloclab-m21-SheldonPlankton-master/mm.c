/**
 * @file mm.c
 * @brief A 64-bit struct-based segregated free list memory allocator
 *
 * 15-213: Introduction to Computer Systems
 *
 * This is a segregated free list implementation of the memory management
 * functions malloc, calloc, realloc and free.
 * 
 * This implementation boasts the following optimizations:
 * - Mini block allocation
 * - No footers needed in allocated blocks
 * - Better fit with adjustable search depth
 *
 * @author Evan Tipping <eftippin@andrew.cmu.edu>
 */

#include <assert.h>
#include <inttypes.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "memlib.h"
#include "mm.h"

/* Do not change the following! */

#ifdef DRIVER
/* create aliases for driver tests */
#define malloc mm_malloc
#define free mm_free
#define realloc mm_realloc
#define calloc mm_calloc
#define memset mem_memset
#define memcpy mem_memcpy
#endif /* def DRIVER */

/* You can change anything from here onward */

/*
 *****************************************************************************
 * If DEBUG is defined (such as when running mdriver-dbg), these macros      *
 * are enabled. You can use them to print debugging output and to check      *
 * contracts only in debug mode.                                             *
 *                                                                           *
 * Only debugging macros with names beginning "dbg_" are allowed.            *
 * You may not define any other macros having arguments.                     *
 *****************************************************************************
 */
#ifdef DEBUG
/* When DEBUG is defined, these form aliases to useful functions */
#define dbg_printf(...) printf(__VA_ARGS__)
#define dbg_requires(expr) assert(expr)
#define dbg_assert(expr) assert(expr)
#define dbg_ensures(expr) assert(expr)
#define dbg_printheap(...) print_heap(__VA_ARGS__)
#else
/* When DEBUG is not defined, no code gets generated for these */
/* The sizeof() hack is used to avoid "unused variable" warnings */
#define dbg_printf(...) (sizeof(__VA_ARGS__), -1)
#define dbg_requires(expr) (sizeof(expr), 1)
#define dbg_assert(expr) (sizeof(expr), 1)
#define dbg_ensures(expr) (sizeof(expr), 1)
#define dbg_printheap(...) ((void)sizeof(__VA_ARGS__))
#endif

/* Types */

typedef uint64_t word_t;

/** @brief Represents the header and payload of one block in the heap */
typedef struct block {
    /** @brief Header contains size + allocation flag */
    word_t header;
    union {
        // These are used for free block pointers
        struct {
            struct block *prev;
            struct block *next;
        };
        char payload[0];
    };
} block_t;

/** @brief Mini blocks are similar to normal block_t, but don't have a header
 * if they are free.
 */
typedef struct block_mini {
    union {
        struct {
            struct block_mini *prev;
            struct block_mini *next;
        };
        struct {
            word_t header;
            word_t payload;
        };
    };
} block_m_t;



/* Basic constants */

/** @brief Word and header size (bytes) */
static const size_t wsize = sizeof(word_t);

/** @brief Double word size (bytes) */
static const size_t dsize = 2 * wsize;

/** @brief Minimum block size (bytes) */
static const size_t min_block_size = dsize;

/**
 * @brief Chunksize is the amount by which we extend the heap each time we 
 * request more memory from the OS
 */
static const size_t chunksize = (1 << 12);

/** @brief Masks the bit designating allocation status of the block */
static const word_t alloc_mask = 0x1;

/** @brief Masks the bit designating allocation status of the previous block */
static const word_t alloc_prev_mask = 0x2;

/** @brief Masks the bit designating whether the block is small */
static const word_t small_mask = 0x4;

/** @brief Masks the bits corresponding the sizes, which are multiples of 16 */
static const word_t size_mask = ~(word_t)0xF;

/** @brief Masks the status bits, used for writing to small blocks */
static const word_t status_bits_mask = (word_t)0x7;

/** @brief Number of size classes for seglist allocator */
static const size_t num_sizes = 14;

/**
 * @brief Allocated list sizes, must have length >= num_sizes. Each value is the
 * lower bound for the block sizes and the next index up is the upper bound.
 */
static const size_t size_classes[] = {0x20,  0x30,  0x40,   0x50,   0x60,
                                      0x70,  0x80,  0x100,  0x200,  0x400,
                                      0x800, 0x1000, 0x2000, 0x4000};

static const size_t better_fit_depth = 25;

/** @brief The size of small blocks */
static const size_t size_mini = dsize;



/* Global variables */

/** @brief Pointer to first block in the heap */
static block_t *heap_start = NULL;

/** @brief Pointer to first free block */
static block_t *fblock_classes[num_sizes];

/** @brief mini blocks in separate seglist */
static block_m_t *fblock_m_list = NULL;

/*
 *****************************************************************************
 * The functions below are short wrapper functions to perform                *
 * bit manipulation, pointer arithmetic, and other helper operations.        *
 *                                                                           *
 * We've given you the function header comments for the functions below      *
 * to help you understand how this baseline code works.                      *
 *                                                                           *
 * Note that these function header comments are short since the functions    *
 * they are describing are short as well; you will need to provide           *
 * adequate details for the functions that you write yourself!               *
 *****************************************************************************
 */

/*
 * ---------------------------------------------------------------------------
 *                        BEGIN SHORT HELPER FUNCTIONS
 * ---------------------------------------------------------------------------
 */

/**
 * @brief Returns the maximum of two integers.
 * @param[in] x
 * @param[in] y
 * @return `x` if `x > y`, and `y` otherwise.
 */
static size_t max(size_t x, size_t y) {
    return (x > y) ? x : y;
}

/**
 * @brief Rounds `size` up to next multiple of n
 * @param[in] size
 * @param[in] n
 * @return The size after rounding up
 */
static size_t round_up(size_t size, size_t n) {
    return n * ((size + (n - 1)) / n);
}

/**
 * @brief Packs the `size` and `alloc` of a block into a word suitable for
 *        use as a packed value.
 *
 * Packed values are used for both headers and footers.
 *
 * The allocation status is packed into the lowest bit of the word.
 *
 * @param[in] size The size of the block being represented
 * @param[in] alloc True if the block is allocated
 * @return The packed value
 */
static word_t pack(size_t size, bool alloc) {
    word_t word = size;
    if (alloc) {
        word |= alloc_mask;
    }
    return word;
}

/**
 * @brief Extracts the size represented in a packed word.
 *
 * This function simply clears the lowest 4 bits of the word, as the heap
 * is 16-byte aligned.
 *
 * @param[in] word
 * @return The size of the block represented by the word
 */
static size_t extract_size(word_t word) {
    if (word & small_mask)
        return min_block_size;
    return (word & size_mask);
}

/**
 * @brief Extracts the size of a block from its header.
 * @param[in] block
 * @return The size of the block
 */
static size_t get_size(block_t *block) {
    return extract_size(block->header);
}

/**
 * @brief Given a payload pointer, returns a pointer to the corresponding
 *        block.
 * @param[in] bp A pointer to a block's payload
 * @return The corresponding block
 */
static block_t *payload_to_header(void *bp) {
    return (block_t *)((char *)bp - offsetof(block_t, payload));
}

/**
 * @brief Given a block pointer, returns a pointer to the corresponding
 *        payload.
 * @param[in] block
 * @return A pointer to the block's payload
 * @pre The block must be a valid block, not a boundary tag.
 */
static void *header_to_payload(block_t *block) {
    dbg_requires(get_size(block) != 0);
    return (void *)(block->payload);
}

/**
 * @brief Given a block pointer, returns a pointer to the corresponding
 *        footer.
 * @param[in] block
 * @return A pointer to the block's footer
 * @pre The block must be a valid block, not a boundary tag.
 */
static word_t *header_to_footer(block_t *block) {
    dbg_requires(get_size(block) != 0 &&
                 "Called header_to_footer on the epilogue block");
    return (word_t *)(block->payload + get_size(block) - dsize);
}

/**
 * @brief Given a block footer, returns a pointer to the corresponding
 *        header.
 * @param[in] footer A pointer to the block's footer
 * @return A pointer to the start of the block
 * @pre The footer must be the footer of a valid block, not a boundary tag.
 */
static block_t *footer_to_header(word_t *footer) {
    size_t size = extract_size(*footer);
    dbg_assert(size != 0 && "Called footer_to_header on the prologue block");
    return (block_t *)((char *)footer + wsize - size);
}

/**
 * @brief Returns the payload size of a given block.
 *
 * The payload size is equal to the entire block size minus the sizes of the
 * block's header and footer.
 *
 * @param[in] block
 * @return The size of the block's payload
 */
static size_t get_payload_size(block_t *block) {
    size_t asize = get_size(block);
    return asize - wsize;
}

/**
 * @brief Returns the allocation status of a given header value.
 *
 * This is based on the lowest bit of the header value.
 *
 * @param[in] word
 * @return The allocation status correpsonding to the word
 */
static bool extract_alloc(word_t word) {
    return (bool)(word & alloc_mask);
}

/**
 * @brief Returns the allocation status of a block, based on its header.
 * @param[in] block
 * @return The allocation status of the block
 */
static bool get_alloc(block_t *block) {
    return extract_alloc(block->header);
}

/**
 * @brief Writes an epilogue header at the given address.
 *
 * The epilogue header has size 0, and is marked as allocated.
 *
 * @param[out] block The location to write the epilogue header
 */
static void write_epilogue(block_t *block) {
    dbg_requires(block != NULL);
    dbg_requires((char *)block == mem_heap_hi() - 7);
    block->header = pack(0, true);
}

/**
 * @brief Sets the status bits at a given address, used for small blocks.
 *
 * @param[out] header The location to insert the status_bits
 * @param[in] status_bits The state to write to the block, in bits
 */
static void set_status_bits(word_t *header, word_t status_bits) {
    *header &= ~status_bits_mask;
    *header |= status_bits;

    dbg_ensures(get_size((block_t *)header) == size_mini);
}

/**
 * @brief Gets the status bits at a given address, used for small blocks.
 *
 * @param[in] block_m The location to insert the status_bits
 * @return block_m's status bits
 */
static word_t get_status_bits(block_m_t *block_m) {
    word_t *block_m_header = (word_t *)block_m;
    return *block_m_header & status_bits_mask;
}

/**
 * @brief Gets the next small block in the list of free small blocks.
 * Needed as the actual block_m->next contains status bits in the lower places.
 *
 * @param[in] block_m
 * @return block_m's next block
 */
static block_m_t *get_next_mini(block_m_t *block_m) {
    word_t next = ((word_t)block_m->next) & ~status_bits_mask;
    return (block_m_t *)next;
}

/**
 * @brief Gets the prev small block in the list of free small blocks.
 * Needed as the actual block_m->prev contains status bits in the lower places.
 *
 * @param[in] block_m
 * @return block_m's prev block
 */
static block_m_t *get_prev_mini(block_m_t *block_m) {
    word_t prev = ((word_t)block_m->prev) & ~status_bits_mask;
    return (block_m_t *)prev;
}

/**
 * @brief Sets the next small block in the list of free small blocks.
 * Needed as the actual block_m->next contains status bits in the lower places.
 *
 * @param[out] block_m
 * @param[in] nblock_m The block to be set as block_m's next block
 */
static void set_next_mini(block_m_t *block_m, block_m_t *nblock_m) {
    dbg_requires(get_size((block_t *)block_m) == size_mini);

    word_t block_m_stat = get_status_bits(block_m);
    block_m->next = nblock_m;
    set_status_bits((word_t *)&block_m->next, block_m_stat);

    dbg_ensures(get_size((block_t *)block_m) == size_mini);
    dbg_ensures(get_status_bits(block_m) == block_m_stat);
    dbg_ensures(get_next_mini(block_m) == nblock_m);
}

/**
 * @brief Sets the prev small block in the list of free small blocks.
 * Needed as the actual block_m->prev contains status bits in the lower places.
 *
 * @param[out] block_m
 * @param[in] pblock_m The block to be set as block_m's prev block
 */
static void set_prev_mini(block_m_t *block_m, block_m_t *pblock_m) {
    dbg_requires(get_size((block_t *)block_m) == size_mini);

    word_t block_m_stat = get_status_bits(block_m);
    block_m->prev = pblock_m;
    set_status_bits((word_t *)&block_m->prev, block_m_stat);

    dbg_ensures(get_size((block_t *)block_m) == size_mini);
    dbg_ensures(get_status_bits(block_m) == block_m_stat);
    dbg_ensures(get_prev_mini(block_m) == pblock_m);
}

/**
 * @brief Finds the next consecutive block on the heap.
 *
 * This function accesses the next block in the "implicit list" of the heap
 * by adding the size of the block.
 *
 * @param[in] block A block in the heap
 * @return The next consecutive block on the heap
 * @pre The block is not the epilogue
 */
static block_t *find_next(block_t *block) {
    dbg_requires(block != NULL);
    dbg_requires(get_size(block) != 0 &&
                 "Called find_next on the last block in the heap");
    return (block_t *)((char *)block + get_size(block));
}

/**
 * @brief Determines the prev_alloc bit of the given word
 *
 * @param[in] word
 * @return the prev alloc bit information of the given word
 */
static bool extract_alloc_prev(word_t word) {
    return (bool)(word & alloc_prev_mask);
}

/**
 * @brief Determines if previous block is allocated based on current block's
 * previous allocation bit
 *
 * @param[in] block
 * @return the allocation of the block previous to our input
 */
static bool get_alloc_prev(block_t *block) {
    return extract_alloc_prev(block->header);
}

/**
 * @brief Handles writing to blocks in the case that we have a mini block
 *
 * @param[out] block_m The block to write our information to
 * @param[in] alloc
 * @param[in] prev_alloc
 */
static void write_mini(block_m_t *block_m, word_t alloc, word_t prev_alloc) {
    word_t status = (alloc) | (prev_alloc) | (small_mask);
    block_m->header = status;
    if (!alloc) {
        block_m->payload = block_m->header;
    }

    dbg_ensures(get_size((block_t *)block_m) == size_mini);
    dbg_ensures(get_alloc((block_t *)block_m) == alloc);
    dbg_ensures(get_alloc_prev((block_t *)block_m) == (bool)prev_alloc);
}

/**
 * @brief Writes a block starting at the given address.
 *
 * This function writes a header, and in free blocks a footer, where the 
 * location of the footer is computed in relation to the header.
 *
 * @param[out] block The location to begin writing the block header
 * @param[in] size The size of the new block
 * @param[in] alloc The allocation status of the new block
 */
static void write_block(block_t *block, size_t size, bool alloc) {
    dbg_requires(block != NULL);
    dbg_requires(size > 0);

    // Preserve allocation of prev block
    word_t prev_alloc;
    prev_alloc = alloc_prev_mask & block->header;

    if (size == size_mini) {
        write_mini((block_m_t *)block, alloc, prev_alloc);

    } else {
        block->header = pack(size, alloc);
        block->header |= prev_alloc;

        // Only need footers in free
        if (!alloc) {
            word_t *footerp = header_to_footer(block);
            *footerp = pack(size, alloc);
        }
    }

    // Write this block's allocation to next block
    block_t *nblock = find_next(block);

    // Clear nblock's old alloc_prev bit and then insert new one
    nblock->header &= ~(alloc_prev_mask);
    nblock->header |= alloc_prev_mask & (alloc << 1);
}

/**
 * @brief Finds the footer of the previous block on the heap.
 * @param[in] block A block in the heap
 * @return The location of the previous block's footer
 */
static word_t *find_prev_footer(block_t *block) {
    // Compute previous footer position as one word before the header
    return &(block->header) - 1;
}

/**
 * @brief Finds the previous consecutive block on the heap.
 *
 * This is the previous block in the "implicit list" of the heap.
 *
 * If the function is called on the first block in the heap, NULL will be
 * returned, since the first block in the heap has no previous block!
 *
 * The position of the previous block is found by reading the previous
 * block's footer to determine its size, then calculating the start of the
 * previous block based on its size.
 * 
 * This can only be called on free blocks.
 *
 * @param[in] block A block in the heap
 * @return The previous consecutive block in the heap.
 */
static block_t *find_prev(block_t *block) {
    dbg_requires(block != NULL);
    word_t *footerp = find_prev_footer(block);

    // Return NULL if called on first block in the heap
    if (extract_size(*footerp) == 0) {
        return NULL;
    }

    return footer_to_header(footerp);
}

/**
 * @brief Get the next block in a segregated free list
 *
 * @param[in] fblock
 * @return The next free block in fblock's seglist
 */
static block_t *next_free_block(block_t *fblock) {
    dbg_requires(fblock != NULL);
    dbg_requires(!get_alloc(fblock));

    return fblock->next;
}

/*
 * ---------------------------------------------------------------------------
 *                        END SHORT HELPER FUNCTIONS
 * ---------------------------------------------------------------------------
 */

/******** The remaining content below are helper and debug routines ********/

/*
 *****************************************************************************
 * The functions below manipulate the doubly linked list of free blocks      *
 *****************************************************************************
 */

/**
 * @brief Prints a given block
 * 
 * @param[in] block
 */
static void print_block(block_t *block) {
    word_t next = (word_t)block->next;
    word_t prev = (word_t)block->prev;
    bool alloc = get_alloc(block);

    printf("    BLOCK: 0x%lx\n", (word_t)block);
    printf("    SIZE:  0x%lx\n", get_size(block));
    printf("     A > %s\n", alloc ? "true" : "false");
    if (!alloc) {
        printf("     N [ 0x%lx ]\n", next);
        printf("     P [ 0x%lx ]\n", prev);
    } else {
        printf("     #\n     #\n");
    }
    printf("\n");
}

/** @brief Prints our heap */
static void print_heap() {

    printf(".------------.\n");
    printf("|-START HEAP-|\n");
    printf("`------------`\n");

    for (block_t *cblock = heap_start; get_size(cblock) > 0;
         cblock = find_next(cblock)) {
        print_block(cblock);
    }

    printf(".------------.\n");
    printf("|--END HEAP--|\n");
    printf("`------------`\n");
    printf("\n\n");
}

/**
 * @brief Gets the minimum block size in a given size class
 *
 * @param[in] i
 * @return the minimum block size in size class i
 */
static size_t get_class_min_size(size_t i) {
    dbg_requires(i < num_sizes);
    return size_classes[i];
}

/**
 * @brief Gets the size class of a given block, which is used to determine where
 * blocks go in our seglist
 *
 * @param[in] size
 * @return the size class that contains blocks that are 'size' in length
 */
static size_t get_size_class(size_t size) {

    if (size == size_mini) return 0;

    // Loop over blocks and compare size to size ranges for each index
    for (size_t i = 0; i < num_sizes - 1; i++) {
        size_t size_i = get_class_min_size(i);
        size_t size_i_bound = get_class_min_size(i + 1);

        if (size_i <= size && size < size_i_bound) {
            return i;
        }
    }

    // Size must be >= lower bound for max list size
    return num_sizes - 1;
}

/**
 * @brief Pushes a mini block into the list of free mini blocks
 *
 * @param[in] fblock_m
 */
static void push_mini(block_m_t *fblock_m) {

    // Clear pointers
    dbg_requires(get_size((block_t *)fblock_m) == size_mini);
    set_next_mini(fblock_m, NULL);
    set_prev_mini(fblock_m, NULL);
    dbg_assert(get_size((block_t *)fblock_m) == size_mini);

    if (fblock_m_list != NULL) {
        set_prev_mini(fblock_m_list, fblock_m);
        set_next_mini(fblock_m, fblock_m_list);
        dbg_assert(get_size((block_t *)fblock_m) == size_mini);
    }

    fblock_m_list = fblock_m;

    dbg_ensures(get_size((block_t *)fblock_m) == size_mini);
}

/**
 * @brief Pushes a block into the proper free list
 *
 * @param[in] fblock
 */
static void push_block(block_t *fblock) {
    // dbg_requires(fblock != NULL);
    // dbg_requires(!get_alloc(fblock)); // Block must have been freed already

    if (get_size(fblock) == size_mini) {
        push_mini((block_m_t *)fblock);
        return;
    }

    size_t size_class;
    size_class = get_size_class(get_size(fblock));

    block_t *size_class_head;
    size_class_head = fblock_classes[size_class];

    // Set block's pointers to NULL
    fblock->next = NULL;
    fblock->prev = NULL;

    // For non-empty stack
    if (size_class_head != NULL) {
        size_class_head->prev = fblock; // Move fblock ahead of fblocks_head
        fblock->next = size_class_head;
    }

    fblock_classes[size_class] = fblock;

    // dbg_requires(check_free_blocks());
}

/**
 * @brief Removes a mini block from the list of free minis
 *
 * @param[in] rblock_m
 */
static void remove_mini(block_m_t *rblock_m) {

    // If rblock is the front of our list
    if (rblock_m == fblock_m_list) {
        fblock_m_list = get_next_mini(rblock_m);
        if (fblock_m_list != NULL) {
            set_prev_mini(fblock_m_list, NULL);
        }
    }

    else {
        // Get previous and next, adjust blocks accordingly
        block_m_t *prev = get_prev_mini(rblock_m);
        block_m_t *next = get_next_mini(rblock_m);
        if (next != NULL) {
            set_prev_mini(next, prev);
        }

        if (prev != NULL) {
            set_next_mini(prev, next);
        }
    }

    set_next_mini(rblock_m, NULL);
    set_prev_mini(rblock_m, NULL);
}

/**
 * @brief Pops the top mini block from the list of mini blocks
 *
 * @return the top mini block from the list of minis
 */
static block_t *pop_mini() {
    block_t *block = (block_t *)fblock_m_list;
    remove_mini(fblock_m_list);
    dbg_ensures(get_size(block) > 0);

    return block;
}

/**
 * @brief Removes a block from its free list regardless of location in list
 *
 * @param[in] rblock
 */
static void remove_block(block_t *rblock) {
    // dbg_requires(rblock != NULL);
    // dbg_requires(get_alloc(rblock) == false);

    if (get_size(rblock) == size_mini) {
        remove_mini((block_m_t *)rblock);
        return;
    }

    size_t size_class;
    size_class = get_size_class(get_size(rblock));

    block_t *size_class_head;
    size_class_head = fblock_classes[size_class];

    if (rblock == size_class_head) {
        fblock_classes[size_class] = rblock->next;
        if (size_class_head != NULL) {
            size_class_head->prev = NULL;
        }
    } else {
        // Get previous and next, adjust blocks accordingly
        block_t *prev = rblock->prev;
        block_t *next = rblock->next;
        if (next != NULL) {
            next->prev = prev;
        }

        if (prev != NULL) {
            prev->next = next;
        }
    }
}

/**
 * @brief Takes in a block and combines it with its next block, making a block
 * starting at ablock with length equal to the sum of ablock's size and the 
 * size of the following block
 *
 * @param[out] ablock the first block to start combining at, where the second
 * block is the next block from ablock in the heap's 'implicit list'
 */
static void combine_neighbors(block_t *ablock) {
    // Ensuring ablock is free, non null and not prologue
    dbg_requires(ablock != NULL);
    dbg_requires(get_size(ablock) > 0);
    dbg_requires(!get_alloc(ablock));

    block_t *bblock = find_next(ablock);

    // Cannot combine with epilogue or unfree block
    dbg_requires(get_size(bblock) > 0);
    dbg_requires(!get_alloc(bblock));

    word_t size_a;
    word_t size_b;

    size_a = get_size(ablock);
    size_b = get_size(bblock);

    write_block(ablock, size_a + size_b, false);
}


/**
 * @brief Tries to make as large of a free block as possible from block and its
 * prior and following blocks. Combines block with each of its free neighbors,
 * making a block that is potentially the size of all three
 *
 * @param[in] block
 * @return the block result from attempting to combine the input with its
 * right and left neighbors
 */
static block_t *coalesce_block(block_t *block) {
    dbg_requires(block != NULL);
    // printf("START OF COALESCE: 0x%lx\n", (word_t)block);

    // No other free blocks, save some time

    block_t *nblock;
    block_t *pblock;

    // Check next block, if it isn't epilogue or alloced we coalesce
    nblock = find_next(block);
    if (get_size(nblock) > 0 && !get_alloc(nblock)) {
        // dbg_assert(is_in_frees(nblock)); // nblock must be among frees

        remove_block(nblock);
        combine_neighbors(block);
    }

    dbg_assert(block != NULL);
    // printf("MIDDLE OF COALESCE: 0x%lx\n", (word_t)block);

    // Check previous block, , if it isn't prologue or alloced we coalesce
    if (!get_alloc_prev(block)) {
        pblock = find_prev(block);
        if (pblock != NULL && get_size(pblock) > 0 && !get_alloc(pblock)) {
            dbg_assert(block != NULL);
            // dbg_assert(is_in_frees(pblock)); // nblock must be among frees

            remove_block(pblock);
            combine_neighbors(pblock);
            block = pblock;
        }
    }
    

    return block;
}

/**
 * @brief Adds more space to the heap when needed
 *
 * @param[in] size
 * @return a pointer to the first byte of the block freshly added to the heap
 */
static block_t *extend_heap(size_t size) {
    void *bp;

    // Allocate an even number of words to maintain alignment
    size = round_up(size, dsize);
    if ((bp = mem_sbrk(size)) == (void *)-1) {
        return NULL;
    }

    // BP is a pointer to the start of the new heap segment.
    // By writing the header, we are overwriting the old epilogue

    // Initialize free block header/footer
    block_t *block = payload_to_header(bp);
    write_block(block, size, false);

    // Create new epilogue header
    block_t *block_next = find_next(block);
    write_epilogue(block_next);

    // Coalesce in case the previous block was free
    block = coalesce_block(block);

    return block;
}

/**
 * @brief Attempts to split off the first asize bytes from the given block to
 * allocate, freeing the remaining bytes as a new block
 *
 * @param[in] block
 * @param[in] asize
 */
static void split_block(block_t *block, size_t asize) {
    dbg_requires(get_alloc(block));
    dbg_requires(asize % dsize == 0);
    dbg_requires(asize > 0);
    /* TODO: Can you write a precondition about the value of asize? */

    size_t block_size = get_size(block);

    if ((block_size - asize) >= min_block_size) {
        block_t *block_next;
        write_block(block, asize, true);

        block_next = find_next(block);
        write_block(block_next, block_size - asize, false);

        push_block(block_next);
    }

    dbg_ensures(get_alloc(block));
}

/**
 * @brief Uses better fit and searches our seglists to find an appropriate 
 * block for allocation
 *
 * @param[in] asize
 * @return the most satisfactory block that could be found that is at least
 * size asize
 */
static block_t *find_fit(size_t asize) {
    block_t *block;

    if (asize == size_mini) {
        if (fblock_m_list != NULL) {
            return pop_mini();
        }
    }

    // Change to next_free_block
    for (size_t size_class = get_size_class(asize); size_class < num_sizes;
         size_class++) {
        block_t *size_class_head = fblock_classes[size_class];
        for (block = size_class_head; block != NULL;
             block = next_free_block(block)) {

            if (asize <= get_size(block)) {
                // Try to find better fit
                block_t *better_block = block;

                // We search for a better block for a little bit
                size_t count = better_fit_depth;
                while (better_block && (count > 0)) {
                    if (get_size(better_block) < get_size(block)) {
                        block = better_block;
                    }
                    count--;
                }
                remove_block(block);

                // Make sure removal worked
                // dbg_assert(!is_in_frees(block));

                return block;
            }
        }
    }

    return NULL; // no fit found
}

/**
 * @brief Determines if the given block exists in our free lists, used for
 * debugging
 *
 * @param[in] block
 * @return whether the block is in the free lists or not
 */
static bool is_in_frees(block_t *block) {
    size_t size = get_size(block);
    size_t size_class = get_size_class(size);
    block_t *size_class_head = fblock_classes[size_class];

    if (get_size(block) == size_mini) {
        for (block_m_t *cblock_m = fblock_m_list; cblock_m != NULL;
             cblock_m = get_next_mini(cblock_m)) {
            if (cblock_m == (block_m_t *)block) {
                return true;
            }
        }
        return false;
    }

    // Linear search for given block
    for (block_t *cblock = size_class_head; cblock != NULL;
         cblock = next_free_block(cblock)) {
        if (cblock == block) {
            return true;
        }
    }

    return false;
}

/**
 * @brief Determines if the pointers in the seglist are valid by ensuring
 * that they are within the heap
 *
 * @param[in] ptr
 * @return whether the given pointer is valid
 */
static bool valid_seglist_ptr(void *ptr) {

    // These pointers can be null
    if (ptr == NULL)
        return true;

    // Pointer is within heap
    return ((void *)heap_start <= ptr) && (ptr < mem_heap_hi() - 7);
}

/**
 * @brief Determines if all free lists are valid, used for debugging
 *
 * @param[in] ptr
 * @return whether the free lists are valid
 */
static bool free_lists_valid() {
    for (block_m_t *cblock_m = fblock_m_list; cblock_m != NULL;
         cblock_m = get_next_mini(cblock_m)) {

        if (get_status_bits((block_m_t *)&cblock_m->header) !=
            get_status_bits((block_m_t *)&cblock_m->payload)) {
            printf("STAUS BITS DIFFER IN BLOCK 0x%zx\n", (word_t)cblock_m);
            return false;
        }
        if (get_alloc((block_t *)cblock_m)) {
            printf("BLOCK 0x%zx IS ALLOCED\n", (word_t)cblock_m);
            return false;
        }
        if (get_size((block_t *)cblock_m) != size_mini) {
            printf("BLOCK 0x%zx IS NOT SMALL\n", (word_t)cblock_m);
            return false;
        }
    }

    for (size_t i = 0; i < num_sizes; i++) {

        // Get size class
        block_t *size_class_head = fblock_classes[i];

        for (block_t *cblock = size_class_head; cblock != NULL;
             cblock = next_free_block(cblock)) {
            // - each block is free
            if (get_alloc(cblock)) {
                printf("BLOCK 0x%zx IS ALLOCED\n", (word_t)cblock);
                return false;
            }
            block_t *prev = cblock->prev;
            block_t *next = cblock->next;

            // If either pointer is outside heap we have a problem
            if (!valid_seglist_ptr(prev) || !valid_seglist_ptr(next)) {
                printf("BLOCK 0x%zx HAS INVALID SEGS\n", (word_t)cblock);
                return false;
            }

            // Make sure block is in correct size class
            size_t size_cblock = get_size(cblock);
            if (get_size(cblock) > mem_heapsize()) {
                printf("BLOCK 0x%zx IS TOO BIG\n", (word_t)cblock);
                return false;
            }

            size_t size_class = get_size_class(size_cblock);

            if (size_class != i) {
                printf("BLOCK 0x%zx IS IN WRONG SIZE %zx\n", (word_t)cblock, i);
                return false;
            }
        }
    }

    // If no problems were found, we have valid free lists
    return true;
}

/**
 * @brief This functions performs a series of validity checks on our heap to
 * ensure that its state is not corrupted
 *
 * @param[in] line
 * @return whether the given heap is valid
 */
bool mm_checkheap(int line) {

    // ENSURE FREE BLOCKS ARE VALID
    if (!free_lists_valid()) {
        printf("CHECKHEAP FAILED:\n INVALID FREE LISTS");
        return false;
    }

    // GET HEAP SIZE
    size_t size_heap = mem_heapsize();
    size_t size_measured = 16; // Include prologue and epilogue in count

    block_t *pblock = NULL;

    // Loop over heap blocks
    for (block_t *cblock = heap_start; get_size(cblock) > 0;
         cblock = find_next(cblock)) {
        bool alloced = get_alloc(cblock);
        bool in_frees = is_in_frees(cblock);

        // ENSURE BLOCKS ARE ALIGNED
        if ((((word_t)cblock) % wsize) != 0) {
            printf("CHECKHEAP FAILED:\n MISALIGNED BLOCK\n");
            // print_heap();
            return false;
        }

        // ENSURE NON FREE BLOCKS AREN'T IN LISTS
        if (alloced && in_frees) {
            printf("CHECKHEAP FAILED:\n ALLOCED BLOCK IN FREES\n");
            // print_heap();
            return false;
        }

        // ENSURE FREE BLOCKS ARE IN FREE LISTS
        if (!alloced && !in_frees) {
            printf("CHECKHEAP FAILED:\n FREE BLOCK NOT STORED IN SEGLISTS\n");
            print_block(cblock);

            return false;
        }

        // ENSURE ALLOC_PREV BIT MATCHES PREVIOUS
        if (pblock != NULL) {
            bool alloc = get_alloc(pblock);
            bool alloc_prev = get_alloc_prev(cblock);

            if (alloc != alloc_prev) {
                printf("INCORRECT ALLOC PREV\n");
                print_heap();
                return false;
            }
        }

        // ENSURE BLOCK SIZE IS VALID
        size_t size_cblock = get_size(cblock);
        if (size_cblock < min_block_size) {
            printf("CHECKHEAP FAILED:\n BLOCK TOO SMALL\n");
            return false;
        }
        if ((size_cblock % wsize) != 0) {
            printf("CHECKHEAP FAILED:\n BLOCK SIZE IS NOT ALIGNED\n");
            return false;
        }

        pblock = cblock;
        size_measured += size_cblock;
    }

    // ENSURE TOTAL SIZE IS CORRECT
    if (size_heap != size_measured) {
        printf("CHECKHEAP FAILED:\n HEAP WRONG SIZE\n");
        return false;
    }

    return true;
}

/**
 * @brief Initialize the heap with a prologue, epilogue and a free block of 
 * size chunksize
 *
 * @return whether the initialization succeeded
 */
bool mm_init(void) {
    // Create the initial empty heap
    word_t *start = (word_t *)(mem_sbrk(2 * wsize));

    if (start == (void *)-1) {
        return false;
    }

    // Create heap prologue and epilogue for coalescing purposess
    start[0] = pack(0, true); // Heap prologue (block footer)
    start[1] = pack(0, true); // Heap epilogue (block header)

    // Heap starts with first "block header", currently the epilogue
    heap_start = (block_t *)&(start[1]);

    // Extend the empty heap with a free block of chunksize bytes
    block_t *sblock = extend_heap(chunksize);
    if (sblock == NULL) {
        return false;
    }

    // Resetting fblock lists
    for (size_t i = 0; i < num_sizes; i++) {
        fblock_classes[i] = NULL;
    }
    push_block(sblock);

    return true;
}

/**
 * @brief Allocates a free block from the heap and gives it to the caller to
 * use
 *
 * @param[in] size
 * @return a pointer to the payload of block of at least size bytes
 */
void *malloc(size_t size) {
    dbg_requires(mm_checkheap(__LINE__));

    size_t asize;      // Adjusted block size
    size_t extendsize; // Amount to extend heap if no fit is found
    block_t *block;
    void *bp = NULL;

    // Initialize heap if it isn't initialized
    if (heap_start == NULL) {
        mm_init();
    }

    // Ignore spurious request
    if (size == 0) {
        dbg_ensures(mm_checkheap(__LINE__));
        return bp;
    }

    // Adjust block size to include overhead and to meet alignment requirements
    asize = round_up(size + wsize, dsize);
    //asize = max(asize, min_block_size);

    // Search the free list for a fit
    block = find_fit(asize);

    // If no fit is found, request more memory, and then and place the block
    if (block == NULL) {
        // Always request at least chunksize
        extendsize = max(asize, chunksize);
        block = extend_heap(extendsize);
        // extend_heap returns an error
        if (block == NULL) {
            return bp;
        }
    }

    // The block should be marked as free
    dbg_assert(!get_alloc(block));

    // Mark block as allocated
    size_t block_size = get_size(block);
    write_block(block, block_size, true);

    // Try to split the block if too large
    split_block(block, asize);

    bp = header_to_payload(block);

    dbg_ensures(mm_checkheap(__LINE__));
    return bp;
}

/**
 * @brief Takes the given pointer that was previously given to the caller by
 * malloc and procedes to free it for later malloc calls
 *
 * @param[in] bp
 */
void free(void *bp) {
    dbg_requires(mm_checkheap(__LINE__));

    if (bp == NULL) {
        return;
    }

    block_t *block = payload_to_header(bp);

    size_t size = get_size(block);

    // The block should be marked as allocated
    dbg_assert(get_alloc(block));

    // Mark the block as free
    write_block(block, size, false);

    // Try to coalesce the block with its neighbors
    dbg_assert(block != NULL);
    block = coalesce_block(block);

    push_block(block);

    dbg_ensures(mm_checkheap(__LINE__));
}

/**
 * @brief Reallocates a given block of memory with a different size
 *
 * @param[in] ptr
 * @param[in] size
 * @return a new block with the same information written to the payload
 */
void *realloc(void *ptr, size_t size) {
    block_t *block = payload_to_header(ptr);
    size_t copysize;
    void *newptr;

    // If size == 0, then free block and return NULL
    if (size == 0) {
        free(ptr);
        return NULL;
    }

    // If ptr is NULL, then equivalent to malloc
    if (ptr == NULL) {
        return malloc(size);
    }

    // Otherwise, proceed with reallocation
    newptr = malloc(size);

    // If malloc fails, the original block is left untouched
    if (newptr == NULL) {
        return NULL;
    }

    // Copy the old data
    copysize = get_payload_size(block); // gets size of old payload
    if (size < copysize) {
        copysize = size;
    }
    memcpy(newptr, ptr, copysize);

    // Free the old block
    free(ptr);

    return newptr;
}

/**
 * @brief Allocates a block of size at least elements * size bytes, with each 
 * byte initialized to zero
 *
 * @param[in] elements
 * @param[in] size
 * @return a pointer to the payload of a block with the
 */
void *calloc(size_t elements, size_t size) {
    void *bp;
    size_t asize = elements * size;

    if (elements == 0) {
        return NULL;
    }
    if (asize / elements != size) {
        // Multiplication overflowed
        return NULL;
    }

    bp = malloc(asize);
    if (bp == NULL) {
        return NULL;
    }

    // Initialize all bits to 0
    memset(bp, 0, asize);

    return bp;
}

/*
 *****************************************************************************
 * Do not delete the following super-secret(tm) lines!                       *
 *                                                                           *
 * 53 6f 20 79 6f 75 27 72 65 20 74 72 79 69 6e 67 20 74 6f 20               *
 *                                                                           *
 * 66 69 67 75 72 65 20 6f 75 74 20 77 68 61 74 20 74 68 65 20               *
 * 68 65 78 61 64 65 63 69 6d 61 6c 20 64 69 67 69 74 73 20 64               *
 * 6f 2e 2e 2e 20 68 61 68 61 68 61 21 20 41 53 43 49 49 20 69               *
 *                                                                           *
 * 73 6e 27 74 20 74 68 65 20 72 69 67 68 74 20 65 6e 63 6f 64               *
 * 69 6e 67 21 20 4e 69 63 65 20 74 72 79 2c 20 74 68 6f 75 67               *
 * 68 21 20 2d 44 72 2e 20 45 76 69 6c 0a c5 7c fc 80 6e 57 0a               *
 *                                                                           *
 *****************************************************************************
 */