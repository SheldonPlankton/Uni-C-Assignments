// C Template by Evan Tipping
/*                                                                            *\
|*]==========================================================================[*|
 \\>                                                                        <//
  }}>                            Project Title                             <{{
 //>                                                                        <\\
|*]==========================================================================[*|
|*                                                                            *|
|*    Author: Evan Tipping                                                    *|
|*    Date:   6/28/2021                                                       *|
|*                                                                            *|
|*>~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~<*|
|*>   Changelog:                                                              *|
|*>~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~<*|
> None

// DELETE: GP - 25HTjnMKBAcnAR4

|*]==========================================================================[*|
||    Includes:                                                               ||
\*]==========================================================================[*/
#include "cachelab.h"
#include <getopt.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>

/*]==========================================================================[*\
||                                                                            ||
||                           Constants and Datatypes                          ||
\*]==========================================================================[*/

/*--------------------------------*\
[              GLOBS               ]
\*--------------------------------*/
const int BIT_LIMIT = 63; // Highest bit address
const int MAX_REQUEST_CHARS = 128;

/*--------------------------------*\
[           64 Bit Vector          ]
\*--------------------------------*/
typedef long long unsigned bitvect64; // This is a convenient alias

/*--------------------------------*\
[              Lines               ]
\*--------------------------------*/
typedef struct {
    bool d;            // Dirty bit
    bool v;            // Valid bit
    bitvect64 priority; // Val from 1 to n, where n is LRU line
    bitvect64 tag;      // Tag associated
} cline_t;

/*--------------------------------*\
[               Sets               ]
\*--------------------------------*/
typedef cline_t* cset_t;

/*--------------------------------*\
[           Cache Storage          ]
\*--------------------------------*/
typedef struct {
    int b;         // Bits in block offset
    int s;         // Bits in set index 
    int num_bytes; // Number of bytes per line
    int num_sets;  // Number of sets in cache
    int num_lines; // Number of lines per set
    cset_t* sets;  // Set array
} cache_t;

/*]==========================================================================[*\
||                                                                            ||
||                              XALLOC Functions                              ||
\*]==========================================================================[*/
// Each of these is obtained from 15-122 course content, used with permission

/* xcalloc(nobj, size) returns a non-NULL pointer to
 * array of nobj objects, each of size size and
 * exits if the allocation fails.  Like calloc, the
 * array is initialized with zeroes.
 */
void *xcalloc(size_t nobj, size_t size) {
    void *p = calloc(nobj, size);
    if (p == NULL) {
        fprintf(stderr, "allocation failed\n");
        abort();
    }
    return p;
}

/* xmalloc(size) returns a non-NULL pointer to
 * an object of size size and exits if the allocation
 * fails.  Like malloc, no initialization is guaranteed.
 */
void *xmalloc(size_t size) {
    void *p = malloc(size);
    if (p == NULL) {
        fprintf(stderr, "allocation failed\n");
        abort();
    }
    return p;
}

/*]==========================================================================[*\
||                                                                            ||
||                         Cache Simulator Operations                         ||
\*]==========================================================================[*/

// Create a cache with the provided stats
// IN
// s - number of set bits
// E - lines per set
// b - bytes per line

// OUT
cache_t* make_cache(int s, int E, int b) {
    // Computing storage sizes
    int B, S;
    B = 1 << b;
    S = 1 << s;

    // Allocating structures
    cache_t *C;
    cset_t  *sets;
    
    // Start fields of cache
    C = xmalloc(sizeof(cache_t));
    C->b = b;
    C->s = s;
    C->num_sets = S;
    C->num_lines = E;
    C->num_bytes = B;

    // Allocate array of sets
    sets = xcalloc(S, sizeof(cset_t));

    // Allocate lines
    for (int i = 0; i < S; i++) {
        cline_t *lines;
        lines = xcalloc(E, sizeof(cline_t));

        for (int j = 0; j < E; j++) {
            cline_t line; 

            // Set init vals
            line.d = false;
            line.v = false;
            line.priority = 0;
            line.tag = 0;

            lines[j] = line;
        }
        
        sets[i] = lines;
    }

    C->sets = sets;

    return C;
}

void free_cache(cache_t* C) {
    // Free lines
    for (int i = 0; i < C->num_sets; i++) {
        free(C->sets[i]);
    }
    free(C->sets);
    free(C);
}

// Borrowed and slightly modified from my datalab submission. This function
// creates a bit mask of a specified form
bitvect64 bit_mask(bitvect64 highbit, bitvect64 lowbit) {
    bitvect64 ones, maskLow, maskHigh;
    ones = ~0;
    maskLow = ones << lowbit;
    maskHigh = ~((ones << 1) << highbit);
    return maskLow & maskHigh;
}

// This parses the set from a given address
bitvect64 parse_set(bitvect64 addr, int s, int b) {
    if (s == 0) return 0;

    bitvect64 set_mask = bit_mask(b+s-1, b);
    bitvect64 set_bits = addr & set_mask;

    return set_bits >> b;
}

// This parses the tag from a given address
bitvect64 parse_tag(bitvect64 addr, int s, int b) {
    bitvect64 tag_mask = bit_mask(BIT_LIMIT, b + s);
    bitvect64 tag_bits = addr & tag_mask;
    
    return tag_bits >> (s + b);
}

// This function updates the LRU status of each line in a set, which
// is indicated by the priority field.
void update_priorities(cset_t set, int E, int most_recent_index) {
    // Store the previous most recent so we only change when needed
    static int most_recent_prev = -1;

    if (most_recent_prev == most_recent_index) return;

    for (int i = 0; i < E; i++) {

        // Add 1 to priority of less recent blocks
        if (i != most_recent_index) {
            if (set[i].v) {
                set[i].priority++;
            }
        }
        printf("%Lx ", set[i].priority);
    }
    printf(" <- Priorities\n");

    // Set the previous index to the current for later
    most_recent_prev = most_recent_index;
}


// This performs a simulated load, adjusting the cache accordingly
void load_op(cache_t *C, bitvect64 addr, csim_stats_t* stats) {
    bitvect64 set_bits;
    set_bits = parse_set(addr, C->s, C->b);

    bitvect64 tag_bits;
    tag_bits = parse_tag(addr, C->s, C->b);

    // Eviction-free load flag
    bool eviction_needed = true;

    // Index into set, loop over lines
    cset_t set = C->sets[set_bits];
    
    for (int i = 0; i < C->num_lines; i++) {

        // Cold miss
        if (!set[i].v) {

            // Line is valid now
            set[i].v = true;
            set[i].tag = tag_bits;

            // Increase priority of other lines
            update_priorities(set, C->num_lines, i);
            set[i].priority = 1;

            stats->misses++;
            eviction_needed = false;
            break;
        }

        // Hit!
        else if (set[i].tag == tag_bits) {

            // Increase priority of other lines
            update_priorities(set, C->num_lines, i);
            set[i].priority = 1;

            stats->hits++;
            eviction_needed = false;
            break;
        }
    }

    if (eviction_needed) {
        int MRU = -1;
        for (int i = 0; i < C->num_lines; i++) {
            if (set[i].priority == C->num_lines) {
                MRU = i;
                set[i].tag = tag_bits;
                set[i].d   = false;

                stats->misses++;
                stats->evictions++;
                if (set[i].d)
                    stats->dirty_evictions += 1 << C->b;
            }
        }
        update_priorities(set, C->num_lines, MRU);
        set[MRU].priority = 1;
    }
}

// This performs a simulated save, adjusting the cache accordingly
void save_op(cache_t *C, bitvect64 addr, csim_stats_t *stats) {
    bitvect64 set_bits;
    set_bits = parse_set(addr, C->s, C->b);

    bitvect64 tag_bits;
    tag_bits = parse_tag(addr, C->s, C->b);

    // Eviction-free load flag
    bool eviction_needed = true;

    // Index into set, loop over lines
    cset_t set = C->sets[set_bits];

    for (int i = 0; i < C->num_lines; i++) {

        // Cold miss
        if (!set[i].v) {
            // Line is valid now
            set[i].v = true;
            set[i].d = true;
            set[i].tag = tag_bits;

            // Increase priority of other lines
            update_priorities(set, C->num_lines, i);
            set[i].priority = 1;

            stats->misses++;
            eviction_needed = false;
            break;
        }

        // Hit!
        else if (set[i].tag == tag_bits) {
            set[i].d = true;

            // Increase priority of other lines
            update_priorities(set, C->num_lines, i);
            set[i].priority = 1;

            stats->hits++;
            eviction_needed = false;
            break;
        }
    }

    if (eviction_needed) {
        int MRU = -1;
        for (int i = 0; i < C->num_lines; i++) {
            if (set[i].priority == C->num_lines) {
                MRU = i;
                set[i].tag = tag_bits;
                set[i].d = true;

                stats->misses++;
                stats->evictions++;

                if (set[i].d)
                    stats->dirty_evictions += 1 << C->b;
            }
        }
        update_priorities(set, C->num_lines, MRU);
        set[MRU].priority = 1;
    }
}

void run_csim(FILE *trace_file, cache_t *C, csim_stats_t *stats) {
    // Loop over trace and eval each op
    char request[MAX_REQUEST_CHARS];
    while (fgets(request, MAX_REQUEST_CHARS, trace_file) != 0) {
        char op;
        bitvect64 addr;

        // Extract op and address
        sscanf(request, "%c %Lx", &op, &addr);

        switch (op) {
        case 'L':
            load_op(C, addr, stats);
            break;
        case 'S':
            save_op(C, addr, stats);
            break;
        default:
            break;
        }
    }
}

void count_dirty(cache_t *C, csim_stats_t *stats) {
    // Loop over cache and count up each dirty bit
    int dirty_lines = 0;
    for (int i = 0; i < C->num_sets; i++) {
        cset_t set = C->sets[i];
        for (int j = 0; j < C->num_lines; j++) {
            if (set[j].d) dirty_lines++;
        }
    }

    // Definition of number of dirty bytes
    stats->dirty_bytes = dirty_lines * C->num_bytes;
}
/*--------------------------------*\
[           Cache Stats            ]
\*--------------------------------*/
int main(int argc, char **argv) {
    int s, E, b;
    s = b = E = 0;

    char *trace_name;
    trace_name = NULL;

    // Parse command line args
    int opt;
    while((opt = getopt(argc, argv, "s:E:b:t:")) != -1) {
        switch(opt) {
            case 's':
                s = atoi(optarg);
                printf("%c : %i\n", opt, atoi(optarg));
                break;
            case 'b':
                b = atoi(optarg);
                printf("%c : %i\n", opt, atoi(optarg));
                break;
            case 'E':
                E = atoi(optarg);
                printf("%c : %i\n", opt, atoi(optarg));
                break;
            case 't':
                trace_name = optarg;
                printf("Trace: %s\n", trace_name);
                break;
            default:
                printf("funky, wrong symbol dingus");
                break;
        }
        
    }

    if (trace_name == NULL) {
        printf("This is wrong, give a trace dingus\n");
        return 0;
    }

    // Setup stats
    csim_stats_t* stats;
    stats = xmalloc(sizeof(csim_stats_t));
    stats->hits            = 0;
    stats->misses          = 0;
    stats->evictions       = 0;
    stats->dirty_evictions = 0;
    stats->dirty_bytes     = 0;

    cache_t* C;
    C = make_cache(s, E, b);

    // Run simulator
    FILE *trace_file;
    trace_file = fopen(trace_name, "r");

    run_csim(trace_file, C, stats);

    // Count dirty bytes
    count_dirty(C, stats);

    printSummary(stats);
    fclose(trace_file);
    free_cache(C);
    free(stats);

    return 0;
}

/*]==========================================================================[*\
||                                                                            ||
|| The End of                                                                 ||
|| Implementation                                                             ||
||                                                                            ||
|*]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[*|
                         ((({{{{{  {{{{@}}}}  }}}}}))))
                                 \  \\\V///  /
      _____                         \ \V/ /                         _____
         wWMMM\                        V                        /MMMWw
           \WWWW\__                                         __/WWWW/
  _____        \WWWw\__\  \           ___           /  /__/wWWWW/       _____
    WWMMM\___      \WWWw\_ w\_    |  /   `  |    _/w _/wWWW/      ___/MMMWW
          WWWWw\     \WWWw\  w\    \ '     /    /w  /wWWW/     /wWWWWW/
                \WWw\    \WW\  w\  ||     ||  /w  /WW/    /wWW/
       ________     \wwWWW\_\W\ W\ \|     |/ /W /W/_/WWWww/     ________
          WWWWWW\_______  \wwWWW\W\ \     / /W/WWWww/  _______/WWWWWW
                \wwwWWWWWwwwww\  w\\ |   | //w   /wwwwWWWWWWwww/
          _________________   WWWWW>\\   //<WWWWWW  _________________
               '"""""""/MWW\___       <?>       ___/WWM\"""""""`
                          __  \\    <_(Y)_>    //   __
       __      .o       c     \_________________/     `      `o..     __
   .       .o.0         \___                      _.__/         .O        `o.
 :             0o           - --o ___ o _  __._--o-            Oo             :
  O               O.Oo.                                 oOo0.                O
    o.                   .oO.o..OO..         o..o.oo.o...                 oO.
       Ooo..                         o..O...                       ..ooOO
            ..oo.                                           ..OOo.
                 ...oo.ooooOO                      ...ooOo..
                              ..oo...oooOOo...Oo..

|*]==========================================================================[*|
||    Interface:                                                              ||
\*]==========================================================================[*/