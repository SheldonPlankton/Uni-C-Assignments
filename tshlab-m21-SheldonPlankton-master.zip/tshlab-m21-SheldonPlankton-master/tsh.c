/**
 * @file tsh.c
 * @brief A tiny shell program with job control
 *
 * A shell that reads input from a user and can execute various commands and run
 * programs. with various methods for managing multiple simultaneous
 * processes.
 *
 * This shell manages an internal joblist.
 *
 * The shell supports the following builtin functions.
 *
 * fg [(%)id]
 *  > move stopped process pid into foreground and continue
 *  > (%) is an optional prefix that instead indicates jid
 *
 * bg [(%)id]
 *  > move process num into foreground and continue
 *  > (%) is an optional prefix that instead indicates jid
 *
 * jobs
 *  > prints out the current job list
 *
 * quit
 *  > exits the shell
 *
 * Additionally, the shell can take in the name of and execute any permitted
 * program that is valid to execve. It can signify that a process should run in
 * the background by appending an ampersand (&) after the name of the program
 * to run.
 *
 * This shell supports typical i/o redirection for processes in the same way
 * a normal linux shell would via the < and > operators.
 *
 * @author Evan Tipping eftippin@andrew.cmu.edu
 */

#include "csapp.h"
#include "tsh_helper.h"

#include <assert.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <getopt.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>

/*
 * If DEBUG is defined, enable contracts and printing on dbg_printf.
 */
#ifdef DEBUG
/* When debugging is enabled, these form aliases to useful functions */
#define dbg_printf(...) printf(__VA_ARGS__)
#define dbg_requires(...) assert(__VA_ARGS__)
#define dbg_assert(...) assert(__VA_ARGS__)
#define dbg_ensures(...) assert(__VA_ARGS__)
#else
/* When debugging is disabled, no code gets generated for these */
#define dbg_printf(...)
#define dbg_requires(...)
#define dbg_assert(...)
#define dbg_ensures(...)
#endif

/* Function prototypes */
void eval(const char *cmdline);

void sigchld_handler(int sig);
void sigtstp_handler(int sig);
void sigint_handler(int sig);
void sigquit_handler(int sig);
void cleanup(void);

// Global variable to determine if foreground job is currently running
bool running_fg;

// Contains information about the parsed argumants to bg and fg commands
typedef struct parse_id_result {
    pid_t pid;
    jid_t jid;
} id_result;

/**
 * @brief Main routine to setup shell.
 *
 * Sets up the environment and other pertinent structures such as the job list
 * before the shell launches. Additionally, this contains the read / eval loop
 * that constitutes the shell's i/o procedure and subsequent evaluation.
 *
 * @param[in] argc Number of args provided to ./tsh
 * @param[in] argv Arguments provided to ./tsh
 */
int main(int argc, char **argv) {
    char c;
    char cmdline[MAXLINE_TSH]; // Cmdline for fgets
    bool emit_prompt = true;   // Emit prompt (default)

    // Redirect stderr to stdout (so that driver will get all output
    // on the pipe connected to stdout)
    if (dup2(STDOUT_FILENO, STDERR_FILENO) < 0) {
        perror("dup2 error");
        exit(1);
    }

    // Parse the command line
    while ((c = getopt(argc, argv, "hvp")) != EOF) {
        switch (c) {
        case 'h': // Prints help message
            usage();
            break;
        case 'v': // Emits additional diagnostic info
            verbose = true;
            break;
        case 'p': // Disables prompt printing
            emit_prompt = false;
            break;
        default:
            usage();
        }
    }

    // Create environment variable
    if (putenv("MY_ENV=42") < 0) {
        perror("putenv error");
        exit(1);
    }

    // Set buffering mode of stdout to line buffering.
    // This prevents lines from being printed in the wrong order.
    if (setvbuf(stdout, NULL, _IOLBF, 0) < 0) {
        perror("setvbuf error");
        exit(1);
    }

    // Initialize the job list
    init_job_list();

    // Register a function to clean up the job list on program termination.
    // The function may not run in the case of abnormal termination (e.g. when
    // using exit or terminating due to a signal handler), so in those cases,
    // we trust that the OS will clean up any remaining resources.
    if (atexit(cleanup) < 0) {
        perror("atexit error");
        exit(1);
    }

    // Install the signal handlers
    Signal(SIGINT, sigint_handler);   // Handles Ctrl-C
    Signal(SIGTSTP, sigtstp_handler); // Handles Ctrl-Z
    Signal(SIGCHLD, sigchld_handler); // Handles terminated or stopped child

    Signal(SIGTTIN, SIG_IGN);
    Signal(SIGTTOU, SIG_IGN);

    Signal(SIGQUIT, sigquit_handler);

    // Execute the shell's read/eval loop
    while (true) {
        if (emit_prompt) {
            printf("%s", prompt);

            // We must flush stdout since we are not printing a full line.
            fflush(stdout);
        }

        if ((fgets(cmdline, MAXLINE_TSH, stdin) == NULL) && ferror(stdin)) {
            perror("fgets error");
            exit(1);
        }

        if (feof(stdin)) {
            // End of file (Ctrl-D)
            printf("\n");
            return 0;
        }

        // Remove any trailing newline
        char *newline = strchr(cmdline, '\n');
        if (newline != NULL) {
            *newline = '\0';
        }

        // Evaluate the command line
        eval(cmdline);
    }

    return -1; // control never reaches here
}

/**
 * @brief Blocks all signals in current process.
 *
 * Masks all signals in the current process.
 * Used for synchronization purposes.
 */
void block_all() {
    sigset_t mask_all;
    sigfillset(&mask_all);
    sigprocmask(SIG_BLOCK, &mask_all, NULL);
}

/**
 * @brief Unblocks all signals in current process.
 *
 * Unmasks all signals in the current process.
 * Used for synchronization purposes.
 */
void unblock_all() {
    sigset_t mask_all;
    sigfillset(&mask_all);
    sigprocmask(SIG_UNBLOCK, &mask_all, NULL);
}

/**
 * @brief Parses id info for fg and bg builtins
 *
 * Parses the id agument to the bg and fg commands.
 *
 * @return Indicates whether parsing was successful or not
 *
 * @param[in] arg The provided argument to fg or bg
 * @param[out] result A pointer to a struct containing the parsed jid or pid
 */
bool parse_id(const char *arg, id_result *result) {

    // -1 indicates that the field was not acquired in parsing
    // These will be filled in if the appropriate values are parsed
    result->pid = -1;
    result->jid = -1;

    char prefix = arg[0]; // Get prefix character
    if (prefix == '\%') {
        if (strlen(arg) < 2) {
            // No digits
            return false;
        } else if (isdigit(arg[1])) {
            // Number seems valid
            result->jid = atoi(arg + 1); // Parse number
            return true;
        } else {
            // Suffix is non numerical
            return false;
        }
    } else if (isdigit(prefix)) {
        // Number seems valid
        result->pid = atoi(arg);
        return true;
    } else {
        return false; // Unsuccessful parse
    }
}

/**
 * @brief Prints job info
 *
 * Takes in information about a job and neatly prints an english human readable
 * representation of the information about that job.
 *
 * @param pid The process id to print about
 * @param cmdline The command line input from user that spawned the job
 * @pre Any signals that could modify the job list must be blocked.
 */
void print_job(pid_t pid, const char *cmdline) {
    printf("[%zx] (%zd) %s\n", (size_t)job_from_pid(pid), (size_t)pid, cmdline);
}

/**
 * @brief Process input given by user on shell's command line.
 *
 * Parses input from user obtained by main's read routine, then execute
 * either a bultin command or launches a program on behalf of the user.
 *
 * @param[in] cmdline The raw command line input from the user
 */
void eval(const char *cmdline) {
    parseline_return parse_result;
    struct cmdline_tokens token;
    int permissions = DEF_MODE; // Experimented with different permissions
    int IN = -1;                // Signifies no input redirect with -1
    int OUT = -1;               // Signifies no output redirect with -1

    // Parse command line
    parse_result = parseline(cmdline, &token);

    if (parse_result == PARSELINE_ERROR || parse_result == PARSELINE_EMPTY) {
        return;
    }

    // Setup input redirection
    if (token.infile != NULL) {
        IN = open(token.infile, O_RDONLY, permissions);
        if (IN < 0) {
            printf("%s: %s\n", token.infile, strerror(errno));
            return;
        }
    }

    // Setup output redirection
    if (token.outfile != NULL) {
        OUT = open(token.outfile, O_WRONLY | O_CREAT | O_TRUNC, permissions);
        if (OUT < 0) {
            printf("%s: %s\n", token.outfile, strerror(errno));
            return;
        }
    }

    running_fg = false; // Reset running flag to avoid race conditions

    // Handle builtin commands
    if (token.builtin != BUILTIN_NONE) {
        pid_t pid;
        jid_t jid;
        id_result result; // Result of parsing id

        // Handle builtin commands
        switch (token.builtin) {
        case BUILTIN_QUIT:
            // Exit normally
            exit(0);
            break;

        case BUILTIN_JOBS:
            // Block signals before printing job list
            block_all();
            list_jobs((OUT != -1) ? OUT : STDOUT_FILENO);
            unblock_all();
            break;

        case BUILTIN_BG:
            // Not enough arguments provided
            if (token.argc < 2) {
                printf("bg command requires PID or %%jobid argument\n");
                return;
            }

            // Parse the provided jid or pid and print error info if parse fails
            if (!parse_id(token.argv[1], &result)) {
                printf("bg: argument must be a PID or %%jobid\n");
                return;
            }

            if (result.jid != -1) {
                jid = result.jid;
                block_all();
                if (!job_exists(jid)) {
                    printf("%%%d: No such job\n", jid);
                    return;
                }
                pid = job_get_pid(jid);
                unblock_all();
            } else if (result.pid != -1) {
                pid = result.pid;
                block_all();
                jid = job_from_pid(pid);
                unblock_all();
            } else {
                // Should be unreachable but signifies an unknown parse issue
                // Needed for compilation
                return;
            }

            // Set job as running in background and print process information
            block_all();
            cmdline = job_get_cmdline(jid);
            job_set_state(jid, BG);
            print_job(pid, cmdline);
            unblock_all();

            // Signal process to continue
            kill(-pid, SIGCONT);
            break;

        case BUILTIN_FG:
            // Not enough arguments provided
            if (token.argc < 2) {
                printf("fg command requires PID or %%jobid argument\n");
                return;
            }
            // Parse the provided jid or pid and print error info if parse fails
            if (!parse_id(token.argv[1], &result)) {
                printf("fg: argument must be a PID or %%jobid\n");
                return;
            }

            if (result.jid != -1) {
                jid = result.jid;
                block_all();
                if (!job_exists(jid)) {
                    printf("%%%d: No such job\n", jid);
                    return;
                }
                pid = job_get_pid(jid);
                unblock_all();
            } else if (result.pid != -1) {
                pid = result.pid;
                block_all();
                jid = job_from_pid(pid);
                unblock_all();
            } else {
                // Should be unreachable but signifies an unknown parse issue
                // Needed for compilation
                return;
            }

            // Set job as running in foreground
            block_all();
            jid = job_from_pid(pid);
            job_set_state(jid, FG);
            running_fg = true;
            unblock_all();

            // Signal process to continue
            kill(-pid, SIGCONT);

            // Loop running sigsuspend until foreground process ends
            block_all();
            while (running_fg) {
                sigset_t mask;
                sigemptyset(&mask);
                sigsuspend(&mask);
            }
            unblock_all();
            break;
        default:
            // UNREACHABLE, something is wrong if we come here
            // Needed for compilation
            printf("< Hehehe how did u find me >:D");
            break;
        }
    } else {
        pid_t pid;
        if (parse_result == PARSELINE_FG)
            running_fg = true;
        block_all();
        if ((pid = fork()) == 0) {
            setpgid(0, 0); // Course staff fix to allow trace 10 to work

            // Redirect child process input
            if (IN != -1) {
                dup2(IN, STDIN_FILENO);
            }

            // Redirect child process output
            if (OUT != -1) {
                dup2(OUT, STDOUT_FILENO);
            }
            unblock_all();

            // Launch child process
            if (execve(token.argv[0], token.argv, environ) < 0) {
                // If child fails to launch, give error information and exit
                printf("%s: %s\n", token.argv[0], strerror(errno));
                exit(0);
            }
        } else {
            // Handle foreground process call
            if (parse_result == PARSELINE_FG) {
                assert(!fg_job());
                add_job(pid, FG, cmdline);
                unblock_all();

                // Loop with sigsuspend until foreground process ends
                block_all();
                while (running_fg) {
                    sigset_t mask;
                    sigemptyset(&mask);
                    sigsuspend(&mask);
                }
                unblock_all();
                // Handle background process call
            } else if (parse_result == PARSELINE_BG) {
                add_job(pid, BG, cmdline);
                print_job(pid, cmdline);
                unblock_all();
            }
        }
    }

    // Close open file descriptors
    if (IN != -1)
        close(IN);
    if (OUT != -1)
        close(OUT);
}

/*****************
 * Signal handlers
 *****************/

/**
 * @brief Handles SIGCHLD received by shell
 *
 * The sigchld_handler is the shell's signal handler for SIGCHLD.
 *
 * This signal handler reaps terminated child processes and appropriately
 * modifies the job list. Additionally, it prints appropriate information about
 * terminated jobs.
 */
void sigchld_handler(int sig) {
    int olderrno = errno;           // Saving errno
    int opts = WNOHANG | WUNTRACED; // We want to return if a job is stopped
    pid_t pid;
    int status;

    // Reap child processes and process stopped children
    while ((pid = waitpid(-1, &status, opts)) > 0) {

        // Acquire foreground job
        block_all();
        jid_t jid = job_from_pid(pid);
        jid_t jid_fg = fg_job();
        unblock_all();

        // If this is the foreground process, tell the shell it can accept input
        if (jid == jid_fg) {
            running_fg = false;
        }

        // Handle a stopped process
        if (WIFSTOPPED(status)) {
            block_all();
            job_set_state(jid, ST);
            unblock_all();

            // Print detailed info about stopped process
            int sig = WSTOPSIG(status);
            sio_printf("Job [%d] (%d) stopped by signal %d\n", jid, pid, sig);
        } else {
            block_all();
            delete_job(jid);
            unblock_all();

            // If the process was terminated via signal, print detailed info
            if (WIFSIGNALED(status)) {
                int sig = WTERMSIG(status);
                sio_printf("Job [%d] (%d) terminated by signal %d\n", jid, pid,
                           sig);
            }
        }
    }

    errno = olderrno; // Restoring saved errno
}

/**
 * @brief Handles SIGINT received by shell
 *
 * The shell's SIGINT handler simply forwards the signal sig to the current
 * foreground process if one is available. Otherwise, it does nothing.
 *
 * @param[in] sig The signal to forward
 */
void sigint_handler(int sig) {
    int olderrno = errno; // Saving errno

    // Block signals before accessing jobs
    block_all();
    jid_t jid_fg = fg_job();

    if (jid_fg != 0) {
        pid_t pid_fg = job_get_pid(jid_fg);
        kill(-pid_fg, sig); // Forward sig to the entire process group of pid
        running_fg = false; // Tell the shell it can accept input
    }
    unblock_all();

    errno = olderrno; // Restoring saved errno
}

/**
 * @brief Handles SIGTSTP received by shell
 *
 * The shell's SIGTSTP handler simply forwards the signal sig to the current
 * foreground process if one is available. Otherwise, it does nothing.
 *
 * @param[in] sig The signal to forward
 */
void sigtstp_handler(int sig) {
    int olderrno = errno; // Saving errno

    // Block signals before accessing jobs
    block_all();
    jid_t jid_fg = fg_job();

    if (jid_fg != 0) {
        pid_t pid_fg = job_get_pid(jid_fg);
        kill(-pid_fg, sig); // Forward sig to the entire process group of pid
        running_fg = false; // Tell the shell it can accept input
    }
    unblock_all();

    errno = olderrno; // Restoring saved errno
}

/**
 * @brief Attempt to clean up global resources when the program exits.
 *
 * In particular, the job list must be freed at this time, since it may
 * contain leftover buffers from existing or even deleted jobs.
 */
void cleanup(void) {
    // Signals handlers need to be removed before destroying the joblist
    Signal(SIGINT, SIG_DFL);  // Handles Ctrl-C
    Signal(SIGTSTP, SIG_DFL); // Handles Ctrl-Z
    Signal(SIGCHLD, SIG_DFL); // Handles terminated or stopped child

    destroy_job_list();
}
